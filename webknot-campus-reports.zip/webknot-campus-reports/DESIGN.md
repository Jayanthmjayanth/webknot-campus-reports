# Design Document — Campus Event Reporting (Prototype)

## Scope
Implements the reporting slice of a campus event platform: events, registrations, attendance, feedback, and reports.

## Data to Track
- **Events**: title, type (Workshop/Fest/Seminar/TechTalk), start/end, college
- **Students**: name, email, college
- **Registrations**: (student ↔ event), timestamp
- **Attendance**: (student ↔ event), status (present/absent), timestamp
- **Feedback**: (student ↔ event), rating 1–5, comment

## Scale Assumptions
~50 colleges × ~500 students × ~20 events/semester. IDs are globally unique, **partitioned by `college_id`** for multi-tenancy. Indexes on foreign keys.

## Database Schema (ER Sketch)
```
College (id PK, name UNIQUE)
  ├─< Student (id PK, college_id FK, name, email, UNIQUE(college_id,email))
  └─< Event   (id PK, college_id FK, title, event_type, starts_at, ends_at, ck: ends>=starts)
        ├─< Registration (id PK, event_id FK, student_id FK, UNIQUE(event_id,student_id))
        ├─< Attendance   (id PK, event_id FK, student_id FK, status, UNIQUE(event_id,student_id))
        └─< Feedback     (id PK, event_id FK, student_id FK, rating [1..5], comment, UNIQUE(event_id,student_id))
```

## API Design (FastAPI)
- `POST /colleges` — create college
- `GET /colleges` — list
- `POST /students` — create student
- `GET /students?college_id=` — list
- `POST /events` — create event
- `GET /events?college_id=&event_type=` — list
- `POST /registrations` — register student to event
- `POST /attendance` — mark attendance (requires registration)
- `POST /feedback` — submit feedback (requires **present** attendance)
- Reports:
  - `GET /reports/event_popularity?college_id=&event_type=` — registrations per event (sorted)
  - `GET /reports/attendance_percentage?event_id=` — registered vs present + %
  - `GET /reports/average_feedback?event_id=` — average rating + count
  - `GET /reports/student_participation?student_id=` — registered/attended counts
  - `GET /reports/top_active_students?college_id=&limit=3` — Top N by attended count
  - `GET /reports/flexible?college_id=&event_type=` — dashboard snapshot (composed)

## Workflows

**Registration → Attendance → Feedback**
1. Student registers for an event (`POST /registrations`)
2. On event day, staff marks attendance (`POST /attendance`) – constrained to registered students.
3. Attendees submit feedback (`POST /feedback`) – only if status=`present`.

**Reporting**
- Popularity: count registrations per event
- Attendance %: present ÷ registered × 100
- Average feedback: mean of `rating`

## Assumptions & Edge Cases
- Duplicate registration prevented by `UNIQUE(event_id,student_id)`.
- Attendance can be marked once per (event, student) – unique constraint.
- Feedback allowed **once** per attendee (unique) and only if they attended (present).
- Students & events must belong to the same college (enforced in service layer).
- Time constraint: `ends_at ≥ starts_at` (DB check).
- Emails unique per college to allow same email across colleges (e.g., alumni domains).
- Deleting a college cascades to child rows (via ORM relationships).

## Multi-Tenancy Decision
Single logical database; rows scoped by `college_id`. This keeps reporting joins simple and is sufficient for the stated scale. For larger scale, consider schema-per-tenant or database-per-tenant.

## Performance Notes
- Indexes on `college_id`, `event_id`, `student_id`.
- Reporting queries use `COUNT` and `AVG` aggregations with `GROUP BY` and outer joins.
- For >10^7 rows, move heavy reports into materialized views or nightly ETL.

## Security & Validation (Prototype Level)
- Open CORS for demo; restrict origins in production.
- Authentication omitted for brevity; add JWT for admin/student roles in real app.
- Pydantic validation for payloads (rating bounds enforced in DB).

## Bonus
- `top_active_students` and `flexible` reports implemented.
- Minimal HTML UI (static/index.html) to exercise core flows.
