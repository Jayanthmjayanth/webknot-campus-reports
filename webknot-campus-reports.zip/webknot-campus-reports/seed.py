from datetime import datetime, timedelta
from app.database import Base, engine, SessionLocal
from app import models

Base.metadata.create_all(bind=engine)
db = SessionLocal()

# Clear all
for tbl in [models.Feedback, models.Attendance, models.Registration, models.Event, models.Student, models.College]:
    db.query(tbl).delete()
db.commit()

# Colleges
c1 = models.College(name="Alpha Institute of Technology")
c2 = models.College(name="Beta College of Engineering")
db.add_all([c1, c2]); db.commit()

# Students
students = [
    models.Student(college_id=c1.id, name="Aarav", email="aarav@alpha.edu"),
    models.Student(college_id=c1.id, name="Diya", email="diya@alpha.edu"),
    models.Student(college_id=c1.id, name="Kabir", email="kabir@alpha.edu"),
    models.Student(college_id=c2.id, name="Neha", email="neha@beta.edu"),
    models.Student(college_id=c2.id, name="Ishaan", email="ishaan@beta.edu"),
]
db.add_all(students); db.commit()

now = datetime.utcnow()
# Events
events = [
    models.Event(college_id=c1.id, title="AI Workshop", event_type="Workshop", starts_at=now, ends_at=now + timedelta(hours=3)),
    models.Event(college_id=c1.id, title="Tech Talk: Cloud", event_type="TechTalk", starts_at=now + timedelta(days=1), ends_at=now + timedelta(days=1, hours=2)),
    models.Event(college_id=c2.id, title="Annual Fest", event_type="Fest", starts_at=now + timedelta(days=2), ends_at=now + timedelta(days=2, hours=5)),
]
db.add_all(events); db.commit()

# Registrations
regs = [
    models.Registration(event_id=events[0].id, student_id=students[0].id),
    models.Registration(event_id=events[0].id, student_id=students[1].id),
    models.Registration(event_id=events[0].id, student_id=students[2].id),
    models.Registration(event_id=events[1].id, student_id=students[0].id),
    models.Registration(event_id=events[2].id, student_id=students[3].id),
    models.Registration(event_id=events[2].id, student_id=students[4].id),
]
db.add_all(regs); db.commit()

# Attendance (mark some present)
atts = [
    models.Attendance(event_id=events[0].id, student_id=students[0].id, status="present"),
    models.Attendance(event_id=events[0].id, student_id=students[1].id, status="present"),
    models.Attendance(event_id=events[1].id, student_id=students[0].id, status="present"),
    models.Attendance(event_id=events[2].id, student_id=students[3].id, status="present"),
]
db.add_all(atts); db.commit()

# Feedback (only for attended students)
fbs = [
    models.Feedback(event_id=events[0].id, student_id=students[0].id, rating=5, comment="Great content!"),
    models.Feedback(event_id=events[0].id, student_id=students[1].id, rating=4, comment="Nice workshop"),
    models.Feedback(event_id=events[1].id, student_id=students[0].id, rating=5, comment="Loved the talk"),
]
db.add_all(fbs); db.commit()

print("Seeded sample data successfully!")
