# Campus Event Reporting — Prototype (FastAPI + SQLite)

> **IMPORTANT:** Per the assignment rules, the final README **must be written by you in your own words** (no AI).  
> Use this file as a starting template and replace everything below with your own understanding.

## How to Run (Quick Start)

### 1) Prerequisites
- Python 3.10+
- pip

### 2) Create & activate a virtual environment
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate
```

### 3) Install dependencies
```bash
pip install -r requirements.txt
```

### 4) Initialize and seed the database (optional but recommended)
```bash
python seed.py
```

### 5) Start the API
```bash
uvicorn app.main:app --reload
```
Open the interactive docs at: http://127.0.0.1:8000/docs

### 6) Open the minimal UI (optional)
Place the static file behind the same host by running uvicorn from project root (already done above), then open:  
`http://127.0.0.1:8000/static/index.html` will not auto-serve; use your browser's file:// to open `static/index.html` **or** serve it via any simple server:

```bash
# Option A: python http server (serves the static directory on port 5500)
cd static
python -m http.server 5500
# Then open http://127.0.0.1:5500/index.html
```

### 7) Demo via curl (optional)
Install `jq` and run:
```bash
bash scripts/curl-demo.sh
```

## Project Structure
```
app/
  database.py
  main.py
  models.py
  schemas.py
static/
  index.html
scripts/
  curl-demo.sh
seed.py
DESIGN.md
README_TEMPLATE.md
queries.sql
requirements.txt
```

## Notes for Evaluators (replace with your own words)
- Assumptions, design choices, deviations from AI suggestions, and limitations.
- Screenshots from Swagger UI illustrating endpoints & reports.
- Any bonus work you attempted.
