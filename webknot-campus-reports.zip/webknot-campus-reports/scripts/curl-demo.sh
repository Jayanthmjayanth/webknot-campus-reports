#!/usr/bin/env bash
set -e

BASE="http://127.0.0.1:8000"

echo "Health:"
curl -s $BASE/ | jq

echo "Colleges:"
curl -s $BASE/colleges | jq

echo "Events (college 1):"
curl -s "$BASE/events?college_id=1" | jq

echo "Popularity:"
curl -s "$BASE/reports/event_popularity?college_id=1" | jq

echo "Attendance % for event 1:"
curl -s "$BASE/reports/attendance_percentage?event_id=1" | jq

echo "Average feedback for event 1:"
curl -s "$BASE/reports/average_feedback?event_id=1" | jq

echo "Student participation for student 1:"
curl -s "$BASE/reports/student_participation?student_id=1" | jq

echo "Top active students in college 1:"
curl -s "$BASE/reports/top_active_students?college_id=1" | jq
