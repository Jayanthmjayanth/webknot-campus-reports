# AI Conversation Log (Placeholder)

Paste screenshots or a transcript link of your AI-assisted brainstorming here.
- Tool used: ChatGPT (example)
- What I asked:
  - Design breakdown
  - Schema & API suggestions
  - How to implement reports
- Where I followed AI:
  - Database schema, unique constraints
  - Reporting endpoints
- Where I deviated:
  - Feedback only if **present** (not just registered)
  - Emails unique per college (not globally)

> Replace this with your actual conversation evidence (screenshots/links) before submission.
