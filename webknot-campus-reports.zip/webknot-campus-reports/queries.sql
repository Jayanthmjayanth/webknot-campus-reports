-- Total registrations per event (optionally filter by college or type)
SELECT e.id AS event_id, e.title, e.event_type, COUNT(r.id) AS registrations
FROM events e
LEFT JOIN registrations r ON r.event_id = e.id
-- WHERE e.college_id = :college_id AND e.event_type = :event_type
GROUP BY e.id
ORDER BY registrations DESC;

-- Attendance percentage for an event
WITH totals AS (
  SELECT
    (SELECT COUNT(*) FROM registrations WHERE event_id = :event_id) AS registered,
    (SELECT COUNT(*) FROM attendance WHERE event_id = :event_id AND status='present') AS present
)
SELECT registered, present, 
       CASE WHEN registered=0 THEN 0 
            ELSE ROUND(present * 100.0 / registered, 2) END AS attendance_percentage
FROM totals;

-- Average feedback score for an event
SELECT AVG(rating) AS avg_rating, COUNT(*) AS responses
FROM feedback
WHERE event_id = :event_id;

-- Student participation report
SELECT s.id AS student_id, s.name,
       (SELECT COUNT(*) FROM registrations r WHERE r.student_id = s.id) AS registered_events,
       (SELECT COUNT(*) FROM attendance a WHERE a.student_id = s.id AND a.status='present') AS attended_events
FROM students s
WHERE s.id = :student_id;

-- Top 3 most active students in a college
SELECT s.id AS student_id, s.name, COUNT(a.id) AS attended
FROM students s
JOIN attendance a ON a.student_id = s.id AND a.status='present'
WHERE s.college_id = :college_id
GROUP BY s.id
ORDER BY attended DESC
LIMIT 3;
