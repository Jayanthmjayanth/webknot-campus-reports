from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func, select
from typing import List, Optional

from .database import Base, engine, get_db
from . import models, schemas

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Campus Event Reporting API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", tags=["health"])
def root():
    return {"ok": True, "service": "Campus Event Reporting API"}

# ---------- Colleges ----------
@app.post("/colleges", response_model=schemas.CollegeOut, tags=["colleges"])
def create_college(payload: schemas.CollegeCreate, db: Session = Depends(get_db)):
    existing = db.query(models.College).filter_by(name=payload.name).first()
    if existing:
        raise HTTPException(400, "College already exists")
    college = models.College(name=payload.name)
    db.add(college)
    db.commit()
    db.refresh(college)
    return college

@app.get("/colleges", response_model=List[schemas.CollegeOut], tags=["colleges"])
def list_colleges(db: Session = Depends(get_db)):
    return db.query(models.College).order_by(models.College.name).all()

# ---------- Students ----------
@app.post("/students", response_model=schemas.StudentOut, tags=["students"])
def create_student(payload: schemas.StudentCreate, db: Session = Depends(get_db)):
    # Avoid duplicate emails inside one college
    existing = db.query(models.Student).filter_by(college_id=payload.college_id, email=payload.email).first()
    if existing:
        raise HTTPException(400, "Student with this email already exists in the college")
    student = models.Student(**payload.model_dump())
    db.add(student)
    db.commit()
    db.refresh(student)
    return student

@app.get("/students", response_model=List[schemas.StudentOut], tags=["students"])
def list_students(college_id: Optional[int] = None, db: Session = Depends(get_db)):
    q = db.query(models.Student)
    if college_id:
        q = q.filter_by(college_id=college_id)
    return q.order_by(models.Student.id.desc()).all()

# ---------- Events ----------
@app.post("/events", response_model=schemas.EventOut, tags=["events"])
def create_event(payload: schemas.EventCreate, db: Session = Depends(get_db)):
    event = models.Event(**payload.model_dump())
    db.add(event)
    db.commit()
    db.refresh(event)
    return event

@app.get("/events", response_model=List[schemas.EventOut], tags=["events"])
def list_events(college_id: Optional[int] = None, event_type: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(models.Event)
    if college_id:
        q = q.filter_by(college_id=college_id)
    if event_type:
        q = q.filter_by(event_type=event_type)
    return q.order_by(models.Event.starts_at.desc()).all()

# ---------- Registrations ----------
@app.post("/registrations", tags=["registrations"])
def register_student(payload: schemas.RegistrationCreate, db: Session = Depends(get_db)):
    # Ensure student & event exist
    event = db.get(models.Event, payload.event_id)
    student = db.get(models.Student, payload.student_id)
    if not event or not student:
        raise HTTPException(404, "Event or Student not found")
    if event.college_id != student.college_id:
        raise HTTPException(400, "Student and Event must belong to the same college")

    existing = db.query(models.Registration).filter_by(event_id=payload.event_id, student_id=payload.student_id).first()
    if existing:
        raise HTTPException(400, "Already registered")
    reg = models.Registration(**payload.model_dump())
    db.add(reg)
    db.commit()
    return {"ok": True, "registration_id": reg.id}

# ---------- Attendance ----------
@app.post("/attendance", tags=["attendance"])
def mark_attendance(payload: schemas.AttendanceCreate, db: Session = Depends(get_db)):
    # Require registration first
    reg = db.query(models.Registration).filter_by(event_id=payload.event_id, student_id=payload.student_id).first()
    if not reg:
        raise HTTPException(400, "Student must be registered for the event before marking attendance")
    existing = db.query(models.Attendance).filter_by(event_id=payload.event_id, student_id=payload.student_id).first()
    if existing:
        raise HTTPException(400, "Attendance already marked")
    att = models.Attendance(**payload.model_dump())
    db.add(att)
    db.commit()
    return {"ok": True, "attendance_id": att.id}

# ---------- Feedback ----------
@app.post("/feedback", tags=["feedback"])
def submit_feedback(payload: schemas.FeedbackCreate, db: Session = Depends(get_db)):
    # Optional: only allow feedback if attendance exists (present or absent allowed? choose present)
    att = db.query(models.Attendance).filter_by(event_id=payload.event_id, student_id=payload.student_id).first()
    if not att or att.status != "present":
        raise HTTPException(400, "Feedback allowed only for students who attended the event (present)")
    existing = db.query(models.Feedback).filter_by(event_id=payload.event_id, student_id=payload.student_id).first()
    if existing:
        raise HTTPException(400, "Feedback already submitted")
    fb = models.Feedback(**payload.model_dump())
    db.add(fb)
    db.commit()
    return {"ok": True, "feedback_id": fb.id}

# ---------- Reports ----------

@app.get("/reports/event_popularity", tags=["reports"])
def event_popularity(college_id: Optional[int] = None, event_type: Optional[str] = None, db: Session = Depends(get_db)):
    q = (
        db.query(
            models.Event.id.label("event_id"),
            models.Event.title,
            models.Event.event_type,
            func.count(models.Registration.id).label("registrations")
        )
        .outerjoin(models.Registration, models.Event.id == models.Registration.event_id)
        .group_by(models.Event.id)
    )
    if college_id:
        q = q.filter(models.Event.college_id == college_id)
    if event_type:
        q = q.filter(models.Event.event_type == event_type)
    rows = q.order_by(func.count(models.Registration.id).desc()).all()
    return [dict(r._mapping) for r in rows]

@app.get("/reports/attendance_percentage", tags=["reports"])
def attendance_percentage(event_id: int, db: Session = Depends(get_db)):
    total = db.query(models.Registration).filter_by(event_id=event_id).count()
    present = db.query(models.Attendance).filter_by(event_id=event_id, status="present").count()
    pct = (present / total * 100.0) if total else 0.0
    return {"event_id": event_id, "registered": total, "present": present, "attendance_percentage": round(pct, 2)}

@app.get("/reports/average_feedback", tags=["reports"])
def average_feedback(event_id: int, db: Session = Depends(get_db)):
    avg = db.query(func.avg(models.Feedback.rating)).filter_by(event_id=event_id).scalar()
    avg = float(avg) if avg is not None else 0.0
    count = db.query(models.Feedback).filter_by(event_id=event_id).count()
    return {"event_id": event_id, "avg_rating": round(avg, 2), "responses": count}

@app.get("/reports/student_participation", tags=["reports"])
def student_participation(student_id: int, db: Session = Depends(get_db)):
    attended = (
        db.query(func.count(models.Attendance.id))
        .filter_by(student_id=student_id, status="present")
        .scalar()
    )
    regs = db.query(func.count(models.Registration.id)).filter_by(student_id=student_id).scalar()
    return {"student_id": student_id, "registered_events": regs, "attended_events": int(attended or 0)}

@app.get("/reports/top_active_students", tags=["reports"])
def top_active_students(college_id: int, limit: int = 3, db: Session = Depends(get_db)):
    rows = (
        db.query(
            models.Student.id.label("student_id"),
            models.Student.name,
            func.count(models.Attendance.id).label("attended")
        )
        .join(models.Attendance, models.Student.id == models.Attendance.student_id)
        .filter(models.Student.college_id == college_id, models.Attendance.status == "present")
        .group_by(models.Student.id)
        .order_by(func.count(models.Attendance.id).desc())
        .limit(limit)
        .all()
    )
    return [dict(r._mapping) for r in rows]

@app.get("/reports/flexible", tags=["reports"])
def flexible(college_id: Optional[int] = None, event_type: Optional[str] = None, db: Session = Depends(get_db)):
    # Composite snapshot for dashboards
    result = {}
    # Popularity
    result["event_popularity"] = event_popularity(college_id, event_type, db)
    # Attendance for each event
    result["attendance"] = [
        {
            "event_id": e["event_id"],
            "title": e["title"],
            "attendance": attendance_percentage(e["event_id"], db)
        }
        for e in result["event_popularity"]
    ]
    return result
