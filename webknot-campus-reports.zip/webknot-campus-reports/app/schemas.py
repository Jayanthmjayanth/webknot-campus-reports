from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional

class CollegeCreate(BaseModel):
    name: str

class CollegeOut(BaseModel):
    id: int
    name: str
    class Config:
        from_attributes = True

class StudentCreate(BaseModel):
    college_id: int
    name: str
    email: str

class StudentOut(BaseModel):
    id: int
    college_id: int
    name: str
    email: str
    class Config:
        from_attributes = True

class EventCreate(BaseModel):
    college_id: int
    title: str
    event_type: str = Field(description="Workshop/Fest/Seminar/TechTalk")
    starts_at: datetime
    ends_at: datetime

class EventOut(BaseModel):
    id: int
    college_id: int
    title: str
    event_type: str
    starts_at: datetime
    ends_at: datetime
    class Config:
        from_attributes = True

class RegistrationCreate(BaseModel):
    event_id: int
    student_id: int

class AttendanceCreate(BaseModel):
    event_id: int
    student_id: int
    status: str = "present"

class FeedbackCreate(BaseModel):
    event_id: int
    student_id: int
    rating: int
    comment: Optional[str] = None
